from .mcfast import *

__doc__ = mcfast.__doc__
if hasattr(mcfast, "__all__"):
    __all__ = mcfast.__all__